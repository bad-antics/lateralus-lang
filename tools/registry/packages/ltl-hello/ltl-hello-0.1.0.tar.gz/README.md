# ltl-hello

A project built with LATERALUS.

## Getting Started

```bash
# Run the project
lateralus run src/main.ltl

# Run tests
lateralus test tests/

# Build
lateralus build src/main.ltl -o build/ltl-hello.ltlc --profile release
```

## Project Structure

```
ltl-hello/
  src/              — Source code
    main.ltl        — Entry point
  tests/            — Test files
  docs/             — Documentation
  examples/         — Example programs
  lateralus.toml    — Project manifest
```
